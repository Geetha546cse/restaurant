import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { Clock, MapPin, Phone, Mail } from 'lucide-react';

export default function App() {
  const menuItems = [
    {
      id: 1,
      name: 'Truffle Pasta',
      description: 'Handmade tagliatelle with black truffle, parmesan, and fresh herbs',
      price: '$28',
      image: 'https://images.unsplash.com/photo-1676300184847-4ee4030409c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwcGFzdGElMjBkaXNofGVufDF8fHx8MTc3MDE5NDI0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'Pasta'
    },
    {
      id: 2,
      name: 'Grilled Ribeye',
      description: '12oz premium ribeye with roasted vegetables and red wine reduction',
      price: '$45',
      image: 'https://images.unsplash.com/photo-1657143378504-681ac84e7b30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmlsbGVkJTIwc3RlYWslMjBkaW5uZXJ8ZW58MXx8fHwxNzcwMjQ5NDIzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'Mains'
    },
    {
      id: 3,
      name: 'Fresh Seafood Platter',
      description: 'Selection of oysters, shrimp, and lobster with mignonette',
      price: '$52',
      image: 'https://images.unsplash.com/photo-1768725845685-b88ca2aa192a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHNlYWZvb2QlMjBwbGF0dGVyfGVufDF8fHx8MTc3MDIwMjA4Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'Seafood'
    }
  ];

  return (
    <div className="size-full overflow-y-auto">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-2xl">La Belle Maison</h1>
            <div className="hidden md:flex gap-8">
              <a href="#home" className="hover:text-gray-600 transition-colors">Home</a>
              <a href="#about" className="hover:text-gray-600 transition-colors">About</a>
              <a href="#menu" className="hover:text-gray-600 transition-colors">Menu</a>
              <a href="#contact" className="hover:text-gray-600 transition-colors">Contact</a>
            </div>
            <button className="bg-black text-white px-6 py-2 rounded-md hover:bg-gray-800 transition-colors">
              Reserve
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1768697358705-c1b60333da35?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwcmVzdGF1cmFudCUyMGludGVyaW9yfGVufDF8fHx8MTc3MDE4MDg0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Restaurant interior"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        <div className="relative z-10 text-center text-white max-w-4xl px-4">
          <h2 className="text-5xl md:text-7xl mb-6">Experience Fine Dining</h2>
          <p className="text-xl md:text-2xl mb-8">Where culinary artistry meets unforgettable ambiance</p>
          <button className="bg-white text-black px-8 py-3 rounded-md text-lg hover:bg-gray-100 transition-colors">
            View Menu
          </button>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl mb-6">Our Story</h2>
              <p className="text-lg text-gray-700 mb-4">
                Since 1985, La Belle Maison has been serving exquisite French-inspired cuisine 
                in an elegant setting. Our commitment to quality ingredients and exceptional 
                service has made us a beloved destination for food enthusiasts.
              </p>
              <p className="text-lg text-gray-700">
                Chef Jean-Pierre brings over 30 years of culinary expertise, creating dishes 
                that celebrate both tradition and innovation. Every plate is a work of art, 
                crafted with passion and precision.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="text-3xl mb-2">🏆</div>
                <p className="text-sm text-gray-600">Michelin Recommended</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="text-3xl mb-2">👨‍🍳</div>
                <p className="text-sm text-gray-600">Award-Winning Chef</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="text-3xl mb-2">🍷</div>
                <p className="text-sm text-gray-600">500+ Wine Selection</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="text-3xl mb-2">⭐</div>
                <p className="text-sm text-gray-600">5-Star Reviews</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">Our Menu</h2>
            <p className="text-lg text-gray-600">Crafted with the finest seasonal ingredients</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {menuItems.map((item) => (
              <div key={item.id} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <div className="h-64 overflow-hidden">
                  <ImageWithFallback
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl">{item.name}</h3>
                    <span className="text-lg text-gray-900">{item.price}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{item.description}</p>
                  <span className="inline-block bg-gray-100 px-3 py-1 rounded-full text-sm text-gray-700">
                    {item.category}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button className="bg-black text-white px-8 py-3 rounded-md hover:bg-gray-800 transition-colors">
              View Full Menu
            </button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">Visit Us</h2>
            <p className="text-lg text-gray-600">We look forward to serving you</p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <div className="flex gap-4">
                <MapPin className="w-6 h-6 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-lg mb-1">Location</h3>
                  <p className="text-gray-600">123 Culinary Boulevard<br />Downtown, New York, NY 10001</p>
                </div>
              </div>

              <div className="flex gap-4">
                <Clock className="w-6 h-6 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-lg mb-1">Hours</h3>
                  <p className="text-gray-600">
                    Monday - Thursday: 5:00 PM - 10:00 PM<br />
                    Friday - Saturday: 5:00 PM - 11:00 PM<br />
                    Sunday: 4:00 PM - 9:00 PM
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <Phone className="w-6 h-6 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-lg mb-1">Phone</h3>
                  <p className="text-gray-600">(555) 123-4567</p>
                </div>
              </div>

              <div className="flex gap-4">
                <Mail className="w-6 h-6 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-lg mb-1">Email</h3>
                  <p className="text-gray-600">reservations@labellemaison.com</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-md">
              <h3 className="text-2xl mb-6">Make a Reservation</h3>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm mb-2">Name</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-2">Email</label>
                  <input 
                    type="email" 
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black"
                    placeholder="your@email.com"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm mb-2">Date</label>
                    <input 
                      type="date" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black"
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-2">Guests</label>
                    <select className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-black">
                      <option>2 guests</option>
                      <option>3 guests</option>
                      <option>4 guests</option>
                      <option>5+ guests</option>
                    </select>
                  </div>
                </div>
                <button 
                  type="submit" 
                  className="w-full bg-black text-white py-3 rounded-md hover:bg-gray-800 transition-colors"
                >
                  Book Table
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-2xl mb-4">La Belle Maison</h3>
          <p className="text-gray-400 mb-4">Fine Dining Experience Since 1985</p>
          <div className="flex justify-center gap-6 text-gray-400">
            <a href="#" className="hover:text-white transition-colors">Instagram</a>
            <a href="#" className="hover:text-white transition-colors">Facebook</a>
            <a href="#" className="hover:text-white transition-colors">Twitter</a>
          </div>
          <p className="text-gray-500 text-sm mt-8">© 2026 La Belle Maison. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
